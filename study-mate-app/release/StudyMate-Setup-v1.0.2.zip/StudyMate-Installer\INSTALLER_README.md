# StudyMate v1.0.2 Installer

This ZIP file contains the StudyMate installer for Windows.

## Installation Instructions:

1. **Extract** this ZIP file to a temporary folder
2. **Right-click** on `Install.bat` and select **"Run as administrator"**
3. **Follow** the installation prompts
4. **Launch** StudyMate from:
   - Desktop shortcut: "StudyMate.lnk"
   - Start Menu: Programs > StudyMate > StudyMate

## What Gets Installed:

- StudyMate application files in `C:\Program Files\StudyMate\`
- Desktop shortcut for easy access
- Start Menu shortcut for all users
- Professional desktop experience

## System Requirements:

- Windows 10 or higher
- Administrator privileges for installation
- No additional software required

## Uninstallation:

Go to "Add or remove programs" in Windows Settings and uninstall "StudyMate".

---
**StudyMate v1.0.2** - Production Release
Built with Electron, React, and TypeScript
